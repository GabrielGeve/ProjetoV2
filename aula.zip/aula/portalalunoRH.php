<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;



?>

<div class="container px-4 py-5" id="featured-3">
    <h2 class="pb-2 border-bottom">Olá, Boas Provas!</h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#collection"></use></svg>
            </div>
            <h2 class="bi bi-calculator">Gestão de Pessoas</h2>
            <p>A gestão de pessoas está no centro das atividades de RH em todos os tipos de negócio, portanto é a primeira entre as principais disciplinas de Recursos Humanos. Afinal, toda organização precisa de uma força de trabalho forte e integrada, sob a orientação de uma gestão eficiente.</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#people-circle"></use></svg>
            </div>
            <h2 class="bi bi-cloud-arrow-up">Gestão de Projetos</h2>
            <p>A gestão de projetos é a prática de planejar, executar, monitorar e concluir o trabalho de uma equipe para atingir objetivos específicos e atender a critérios de sucesso dentro de um prazo tempo especificado ― o que envolve uma série de desafios, especialmente neste momento em que o trabalho de equipes multidisciplinares está em alta..</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"></use></svg>
            </div>
            <h2 class="bi bi-code-slash">Gestão do Conhecimento</h2>
            <p>Além do capital humano, o conhecimento também está entre os principais ativos de uma organização, sobretudo na Era Digital, que foi batizada de Quarta Revolução Industrial. Por definição, gestão de conhecimento é o processo de criação, compartilhamento, uso e gerenciamento de conhecimentos e informações de uma organização.</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
    </div>
</div>
