<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prova</title>
</head>
<body>
<h1 class="text-center">PROVAS EM REVISÃO...</h1>
</body>
</html>



<?php

require_once FOOTER_TEMPLATE;

?>
