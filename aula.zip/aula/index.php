<?php

require_once 'config.php';
require_once 'Crud.php';

$professor = new Crud(HOST,PORT,NAME,USER,PASSWORD,CHAR);
if (isset($_POST) and !empty($_POST)){
    $dados = $_POST;
    $banco = $professor->select('professor',$dados);
    if ($banco->num_rows > 0){
        header('location: sala.php');
    }else{
        $_SESSION['erro'] = "Dados invalidos";
    }
}

?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
    <title>Instituicao</title>
</head>
<body>
<div class="container">
<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    <div class="row align-items-center g-lg-5 py-5">
        <div class="col-md-10 mx-auto col-lg-5">
            <form class="p-4 p-md-5 border rounded-3 bg-light" method="post">
                <h1 class=" fw-bold">LOGIN PROFESSOR</h1>
                <hr class="my-4">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="nome" id="floatingInput" placeholder="Nome" autocomplete="off">
                    <label for="floatingInput">Nome</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="floatingPassword" name="senha" placeholder="Senha">
                    <label for="floatingPassword">Senha</label>
                </div>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Entrar</button>
            </form>
            <?php
                if(isset($_SESSION)){
                echo "<div class='alert alert-danger' role='alert'>
                        $_SESSION[erro]
                </div>";
                }
            ?>
        </div>
    </div>
</div>

<?php

require_once FOOTER_TEMPLATE;

?>
