<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;



?>

<div class="container px-4 py-5" id="featured-3">
    <h2 class="pb-2 border-bottom">Olá, Boas Provas!</h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#collection"></use></svg>
            </div>
            <h2 class="bi bi-calculator">Matemática</h2>
            <p>A matemática é a ciência do raciocínio lógico e abstrato, que estuda quantidades, espaço e medidas, estruturas, variações e estatística. Não há, porém, uma definição consensual por parte da comunidade científica</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#people-circle"></use></svg>
            </div>
            <h2 class="bi bi-cloud-arrow-up">Banco de Dados</h2>
            <p>Um banco de dados é uma coleção organizada de informações - ou dados - estruturadas, normalmente armazenadas eletronicamente em um sistema de computador. Um banco de dados é geralmente controlado por um sistema de gerenciamento de banco de dados (DBMS).</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
        <div class="feature col">
            <div class="">
                <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"></use></svg>
            </div>
            <h2 class="bi bi-code-slash">POO</h2>
            <p>A programação orientada a objetos é um modelo de programação onde diversas classes possuem características que definem um objeto na vida real. Cada classe determina o comportamento do objeto definido por métodos e seus estados possíveis definidos por atributos.</p>
            <a href="prova.php" class="icon-link d-inline-flex align-items-center">
                Ir para Prova
                <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"></use></svg>
            </a>
        </div>
    </div>
</div>
