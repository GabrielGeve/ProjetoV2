<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
require_once 'Crud.php';

$lista = new Crud(HOST,PORT,NAME,USER,PASSWORD,CHAR);

session_start();

if(isset($_POST['enviar']) and !empty($_POST)){
    //var_dump($_POST);
    $chamada = $_POST;
    unset($chamada['enviar']);
    foreach ($chamada as $key => $value){
        //echo "$key : $value <br>";
        $lista->sql_espec("INSERT INTO frequencia VALUES (null,$key,$_SESSION[sala],$value,now())");
    }
    $_SESSION['via'] = "Informações enviada com sucesso";
    header('location: sala.php');

}else{
    $dados = $_POST;
    foreach ($dados as $key => $valor){
        $_SESSION['sala'] = $valor;
    }
    $banco = $lista->select('aluno',$dados);
    $banco->fetch_assoc();
    echo "<form method='post'>";

        foreach ($banco as $teste){
                ?>
                <div class="form-check form-check-inline"><p><?php echo $teste['nome']; ?> :</p></div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="<?php echo $teste['id'] ?>" id="inlineRadio1" value="1">
                    <label class="form-check-label" for="inlineRadio1">Presente</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="<?php echo $teste['id'] ?>" id="inlineRadio2" value="0">
                    <label class="form-check-label" for="inlineRadio2">Falta</label>
                </div>
                <br>
                <?php
        }
    ?>
    <button type="submit" class="btn btn-primary" name="enviar">Enviar</button>
    </form>
    <?php
}

require_once FOOTER_TEMPLATE;


