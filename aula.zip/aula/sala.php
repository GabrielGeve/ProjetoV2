<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
require_once 'Crud.php';
$sala = new Crud(HOST,PORT,NAME,USER,PASSWORD,CHAR);
$dados = [];
$banco = $sala->select('turmas',$dados);
$banco->fetch_assoc();

session_start();

if(isset($_SESSION['via'])){
    ?>
    <div class="alert alert-success" role="alert">
        <?php echo $_SESSION['via']; ?>
    </div>
<?php
}

?>
<div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Escolha sua Turma </h1>
    <div class="col-lg-6 mx-auto">
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <form class="p-2 p-md-5 border rounded-3 bg-light" method="post" action="presenca.php">
                <select class="form-select form-select-lg mb-4" aria-label=".form-select-lg example" name="id_turma">
                    <option selected >Selecione...</option>
                    <?php
                        foreach ($banco as $sala){
                            ?>
                            <option value="<?php echo $sala['id'] ?>"><?php echo $sala['curso'] ?></option>
                    <?php
                        }
                    ?>
                </select>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Escolher</button>
            </form>
        </div>
    </div>
</div>

<?php

require_once FOOTER_TEMPLATE;

?>
