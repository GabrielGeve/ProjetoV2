create schema geforce;
use geforce;

CREATE TABLE aluno (
	id INT AUTO_INCREMENT,
    nome varchar(50),
	senha varchar(30),
	id_turma INT,
	PRIMARY KEY (id),
    FOREIGN KEY (id_turma) REFERENCES turmas(id)
);

insert into professor values(null,'Jonas','teste');

CREATE TABLE professor (
	id INT AUTO_INCREMENT,
    nome varchar(50),
	senha varchar(30),
	PRIMARY KEY (id)
);

CREATE TABLE turmas (
	id INT AUTO_INCREMENT,
	curso varchar(30),
	PRIMARY KEY (id)
);

insert into turmas values(null,'RH');

select * from aluno;

CREATE TABLE frequencia (
	id INT AUTO_INCREMENT,
	id_aluno INT,
    id_turma int,
	chamada char(1),
    dt date,
	PRIMARY KEY (id),
    FOREIGN KEY (id_aluno) REFERENCES aluno(id),
    FOREIGN KEY (id_turma) REFERENCES aluno(id_turma)
);

create table prova (
id int auto_increment primary key,
id_aluno int,
id_turma int,
prova varchar(30)
);


 delimiter //
create trigger tr_liberado after insert on frequencia 
for each row 
begin
	if new.chamada = 1 then 
	insert into prova values (null,new.id_aluno,new.id_turma,'liberado');
	end if;
end //
delimiter ;

CREATE USER 'aluno'@'localhost' identified BY '1234';
GRANT select ON * . * TO 'aluno'@'localhost';
CREATE USER 'professor'@'localhost' identified BY '1234';
GRANT ALL PRIVILEGES ON * . * TO 'professor'@'localhost';




